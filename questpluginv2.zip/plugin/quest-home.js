(function() {
    'use strict';

    const SETTINGS_KEY_SKIP_PLAY_ACTIVITY = 'dqh_skip_play_activity'; // "1" = skip, "0" = don't skip

    function getSkipPlayActivitySetting() {
      try {
        const v = window?.localStorage?.getItem(SETTINGS_KEY_SKIP_PLAY_ACTIVITY);
        // Default to skipping because PLAY_ACTIVITY quests often block/complicate other quest types on web.
        return v !== '0';
      } catch (_) {
        return true;
      }
    }

    function setSkipPlayActivitySetting(skip) {
      try {
        window?.localStorage?.setItem(SETTINGS_KEY_SKIP_PLAY_ACTIVITY, skip ? '1' : '0');
      } catch (_) {
        // ignore
      }
    }
  
    function createQuestButton() {
      if (!window.location.pathname.includes('/quest-home')) {
        const existingButton = document.getElementById('discord-quest-helper-btn');
        if (existingButton) {
          existingButton.remove();
        }
        const existingPanel = document.getElementById('discord-quest-helper-panel');
        if (existingPanel) {
          existingPanel.remove();
        }
        return;
      }
      
      if (document.getElementById('discord-quest-helper-btn')) {
        return;
      }

      // Ensure default setting exists (so quest-code.js has predictable behavior)
      try {
        if (window?.localStorage?.getItem(SETTINGS_KEY_SKIP_PLAY_ACTIVITY) == null) {
          setSkipPlayActivitySetting(true);
        }
      } catch (_) {
        // ignore
      }

      const button = document.createElement('button');
      button.id = 'discord-quest-helper-btn';
      button.textContent = '🚀 Run Quest Code';
      button.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 10000;
        padding: 12px 24px;
        background: linear-gradient(135deg, #5865F2 0%, #7289DA 100%);
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(88, 101, 242, 0.4);
        transition: all 0.3s ease;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      `;

      const panel = document.createElement('div');
      panel.id = 'discord-quest-helper-panel';
      panel.style.cssText = `
        position: fixed;
        bottom: 74px;
        right: 20px;
        z-index: 10001;
        width: 340px;
        padding: 14px 14px 12px 14px;
        background: rgba(20, 22, 26, 0.96);
        color: #EDEFF2;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35);
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
        display: none;
        backdrop-filter: blur(6px);
      `;

      panel.innerHTML = `
        <div style="display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:10px;">
          <div style="font-size:13px; font-weight:700; letter-spacing:0.2px;">Quest Options</div>
          <button id="discord-quest-helper-close" style="
            appearance:none; border:none; background:transparent; color:#AEB3BA;
            cursor:pointer; font-size:18px; line-height:18px; padding:4px 6px; border-radius:8px;
          " title="Close">×</button>
        </div>

        <label style="display:flex; align-items:flex-start; gap:10px; cursor:pointer; user-select:none;">
          <input id="discord-quest-helper-skip-play-activity" type="checkbox" style="margin-top:2px; width:16px; height:16px;" />
          <div>
            <div style="font-size:13px; font-weight:650;">Skip “Play an Activity” quests</div>
            <div style="font-size:12px; color:#AEB3BA; margin-top:6px; line-height:1.35;">
              If your other quests aren’t completing because you have a “Launch/Play Activity on Discord” quest active, keep this checked to ignore those and only run other quest types.
            </div>
          </div>
        </label>

        <div style="display:flex; gap:10px; margin-top:12px;">
          <button id="discord-quest-helper-run" style="
            flex: 1;
            padding: 10px 12px;
            background: linear-gradient(135deg, #5865F2 0%, #7289DA 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 6px 16px rgba(88, 101, 242, 0.35);
          ">Run now</button>
          <button id="discord-quest-helper-cancel" style="
            padding: 10px 12px;
            background: rgba(255,255,255,0.06);
            color: #EDEFF2;
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 10px;
            font-size: 13px;
            font-weight: 650;
            cursor: pointer;
          ">Close</button>
        </div>

        <div style="margin-top:10px; font-size:11.5px; color:#8E95A3; line-height:1.35;">
          Tip: This setting is saved for this Discord tab/domain.
        </div>

        <div style="margin-top:6px; font-size:11px; color:#6F7583; line-height:1.35; text-align:right;">
          Extension developed by Jonah Driver & Cahit
        </div>
      `;
  
      button.addEventListener('mouseenter', () => {
        button.style.transform = 'translateY(-2px)';
        button.style.boxShadow = '0 6px 16px rgba(88, 101, 242, 0.5)';
      });
  
      button.addEventListener('mouseleave', () => {
        button.style.transform = 'translateY(0)';
        button.style.boxShadow = '0 4px 12px rgba(88, 101, 242, 0.4)';
      });

      const checkbox = panel.querySelector('#discord-quest-helper-skip-play-activity');
      const btnRun = panel.querySelector('#discord-quest-helper-run');
      const btnCancel = panel.querySelector('#discord-quest-helper-cancel');
      const btnClose = panel.querySelector('#discord-quest-helper-close');

      function openPanel() {
        checkbox.checked = getSkipPlayActivitySetting();
        panel.style.display = 'block';
      }

      function closePanel() {
        panel.style.display = 'none';
      }

      function resetMainButton() {
        button.textContent = '🚀 Run Quest Code';
        button.style.background = 'linear-gradient(135deg, #5865F2 0%, #7289DA 100%)';
      }

      function showMainButtonError() {
        button.textContent = '❌ Error!';
        button.style.background = 'linear-gradient(135deg, #F23F42 0%, #DC3F41 100%)';
        setTimeout(resetMainButton, 2000);
      }

      function showMainButtonSuccess() {
        button.textContent = '✅ Code Executed!';
        button.style.background = 'linear-gradient(135deg, #23A55A 0%, #2DCE7F 100%)';
        setTimeout(resetMainButton, 2000);
      }

      async function executeQuestCodeFromPanel() {
        setSkipPlayActivitySetting(checkbox.checked);

        btnRun.disabled = true;
        btnRun.style.opacity = '0.85';
        btnRun.style.cursor = 'not-allowed';
        btnRun.textContent = 'Running...';

        chrome.runtime.sendMessage({ action: 'executeQuestCode' }, (response) => {
          btnRun.disabled = false;
          btnRun.style.opacity = '1';
          btnRun.style.cursor = 'pointer';
          btnRun.textContent = 'Run now';

          closePanel();

          if (chrome.runtime.lastError) {
            console.error('Error:', chrome.runtime.lastError);
            showMainButtonError();
          } else if (response && response.success) {
            showMainButtonSuccess();
          } else {
            showMainButtonError();
          }
        });
      }

      button.addEventListener('click', (e) => {
        e.stopPropagation();
        if (panel.style.display === 'none') openPanel();
        else closePanel();
      });

      btnRun.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        executeQuestCodeFromPanel();
      });

      btnCancel.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        closePanel();
      });

      btnClose.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        closePanel();
      });

      document.addEventListener('click', (e) => {
        if (panel.style.display === 'none') return;
        if (panel.contains(e.target) || button.contains(e.target)) return;
        closePanel();
      }, true);
  
      document.body.appendChild(panel);
      document.body.appendChild(button);
    }
  
    function init() {
      createQuestButton();
  
      let lastUrl = window.location.href;
      new MutationObserver(() => {
        const currentUrl = window.location.href;
        if (currentUrl !== lastUrl) {
          lastUrl = currentUrl;
          createQuestButton();
        }
      }).observe(document.body, {
        childList: true,
        subtree: true
      });
  
      const observer = new MutationObserver(() => {
        createQuestButton();
      });
  
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    }
  
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    } else {
      init();
    }
  })();